import React from "react";
import  Card from './Card';

const Container = props =>{
return (
  <Card passData ={props.passData}/>
);
}
export default Container;